import { STATUS_LABELS } from "../lib/util.js";

function Bars({ data, labelMap }) {
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1]);
  const max = Math.max(1, ...entries.map((e) => e[1]));
  return (
    <div className="bars">
      {entries.map(([k, v]) => (
        <div className="b-row" key={k}>
          <span className="b-label">{labelMap ? labelMap[k] || k : k || "—"}</span>
          <span className="b-track">
            <span className="b-fill" style={{ width: `${(v / max) * 100}%` }} />
          </span>
          <span className="b-val">{v}</span>
        </div>
      ))}
    </div>
  );
}

export default function Dashboard({ data }) {
  if (!data) return <div className="empty">Загрузка…</div>;
  const max = data.funnel[0]?.value || 1;
  return (
    <>
      <div className="dash-cards">
        <div className="stat">
          <div className="v">{data.total}</div>
          <div className="l">Маршрутов создано</div>
        </div>
        <div className="stat urgent">
          <div className="v">{data.urgent}</div>
          <div className="l">Срочных находок</div>
        </div>
        <div className="stat">
          <div className="v">{data.by_status["booked"] || 0}</div>
          <div className="l">Записались</div>
        </div>
        <div className="stat">
          <div className="v">{data.by_status["followup"] || data.by_status["closed"] || 0}</div>
          <div className="l">Дошли до контроля</div>
        </div>
      </div>

      <div className="dash-grid">
        <div className="panel">
          <h3>Воронка «находка → лечение»</h3>
          <div className="funnel">
            {data.funnel.map((f) => {
              const pct = Math.round((f.value / max) * 100);
              return (
                <div className="f-row" key={f.label}>
                  <div className="f-top">
                    <span>{f.label}</span>
                    <span>
                      <b>{f.value}</b> · {pct}%
                    </span>
                  </div>
                  <div className="f-track">
                    <div className="f-fill" style={{ width: `${pct}%` }}>
                      {pct > 12 ? pct + "%" : ""}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="panel">
          <h3>Маршруты по специальностям</h3>
          <Bars data={data.by_specialty} />
          <h3 style={{ marginTop: 24 }}>Статусы</h3>
          <Bars data={data.by_status} labelMap={STATUS_LABELS} />
        </div>
      </div>
    </>
  );
}
