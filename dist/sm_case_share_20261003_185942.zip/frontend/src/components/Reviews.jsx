// Раздел для uncertain-пациентов: находка спорная, маршрут не создаётся
// автоматически — координатор/врач решает, подтвердить или отклонить.
export default function Reviews({ reviews, onResolve, pLabel }) {
  if (!reviews.length) {
    return <div className="empty" style={{ padding: 40 }}>Нет находок, требующих уточнения</div>;
  }
  return (
    <div className="audit-wrap">
      <div className="audit-head">
        <h2>Требует уточнения</h2>
        <div className="sub">
          Спорные формулировки («нельзя исключить» и т.п.). Система не создаёт маршрут
          автоматически — требуется решение врача.
        </div>
      </div>

      {reviews.map((rv) => {
        const sr = rv.suggested_route || {};
        return (
          <div className="review-card" key={rv.id}>
            <div className="rc-head">
              <span className="prio prio-urgent">Требует уточнения</span>
              <b>{rv.id}</b>
              <span className="rc-pat">
                пациент {rv.patient?.id}
                {rv.patient?.age ? `, ${rv.patient.age} лет` : ""}
              </span>
              <span className="rc-study">
                {rv.source?.study} · {rv.source?.date?.slice(0, 10)}
              </span>
            </div>

            <div className="rc-body">
              <div className="rc-left">
                <div className="rc-finding-title">{rv.finding.title}</div>
                <div className="rc-marker">Маркер сомнения: «{rv.finding.marker}»</div>
                <div className="rc-evidence">«{rv.finding.evidence}»</div>

                {sr.specialist && (
                  <div className="rc-suggest">
                    Если подтвердить — будет создан маршрут: <b>{sr.specialist}</b> · {sr.next_step}
                    {sr.priority ? ` · ${pLabel(sr.priority)}` : ""}
                  </div>
                )}

                {rv.protocol_text && (
                  <details className="rc-protocol">
                    <summary>Полный протокол исследования</summary>
                    <pre>{rv.protocol_text}</pre>
                  </details>
                )}
              </div>

              <div className="rc-actions">
                <button className="btn primary" onClick={() => onResolve(rv.id, "confirm")}>
                  Подтвердить — создать маршрут
                </button>
                <button className="btn danger" onClick={() => onResolve(rv.id, "reject")}>
                  Отклонить
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
