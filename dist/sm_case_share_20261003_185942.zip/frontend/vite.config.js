import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Фронтенд ходит к локальному FastAPI через прокси — никакой внешней сети.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://127.0.0.1:8000",
    },
  },
});
